--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE raccobio_test;
--
-- Name: raccobio_test; Type: DATABASE; Schema: -; Owner: osm
--

CREATE DATABASE raccobio_test WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C.UTF-8' LC_CTYPE = 'C.UTF-8';


ALTER DATABASE raccobio_test OWNER TO osm;

\connect raccobio_test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: input_ways; Type: TABLE; Schema: public; Owner: osm
--

CREATE TABLE public.input_ways (
    osm_id integer NOT NULL,
    arc_uuid uuid,
    geom public.geometry,
    tags jsonb
);


ALTER TABLE public.input_ways OWNER TO osm;

--
-- Name: output_nodes; Type: TABLE; Schema: public; Owner: osm
--

CREATE TABLE public.output_nodes (
    osrm_node_id bigint NOT NULL,
    node public.geometry,
    tags jsonb,
    abscisse double precision,
    ordonnee double precision
);


ALTER TABLE public.output_nodes OWNER TO osm;

--
-- Name: output_ways; Type: TABLE; Schema: public; Owner: osm
--

CREATE TABLE public.output_ways (
    osrm_way_id bigint NOT NULL,
    arc_uuid uuid,
    geom public.geometry,
    tags jsonb
);


ALTER TABLE public.output_ways OWNER TO osm;

--
-- Name: output_ways_nodes; Type: TABLE; Schema: public; Owner: osm
--

CREATE TABLE public.output_ways_nodes (
    osrm_way_id bigint NOT NULL,
    osrm_node_id bigint NOT NULL,
    arc_uuid uuid,
    "position" integer NOT NULL,
    node public.geometry
);


ALTER TABLE public.output_ways_nodes OWNER TO osm;

--
-- Name: topo_ways_roselend_osm_id_seq; Type: SEQUENCE; Schema: public; Owner: osm
--

CREATE SEQUENCE public.topo_ways_roselend_osm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.topo_ways_roselend_osm_id_seq OWNER TO osm;

--
-- Name: topo_ways_roselend_osm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osm
--

ALTER SEQUENCE public.topo_ways_roselend_osm_id_seq OWNED BY public.input_ways.osm_id;


--
-- Name: input_ways osm_id; Type: DEFAULT; Schema: public; Owner: osm
--

ALTER TABLE ONLY public.input_ways ALTER COLUMN osm_id SET DEFAULT nextval('public.topo_ways_roselend_osm_id_seq'::regclass);


--
-- Data for Name: input_ways; Type: TABLE DATA; Schema: public; Owner: osm
--

COPY public.input_ways (osm_id, arc_uuid, geom, tags) FROM stdin;
\.
COPY public.input_ways (osm_id, arc_uuid, geom, tags) FROM '$$PATH$$/4314.dat';

--
-- Data for Name: output_nodes; Type: TABLE DATA; Schema: public; Owner: osm
--

COPY public.output_nodes (osrm_node_id, node, tags, abscisse, ordonnee) FROM stdin;
\.
COPY public.output_nodes (osrm_node_id, node, tags, abscisse, ordonnee) FROM '$$PATH$$/4315.dat';

--
-- Data for Name: output_ways; Type: TABLE DATA; Schema: public; Owner: osm
--

COPY public.output_ways (osrm_way_id, arc_uuid, geom, tags) FROM stdin;
\.
COPY public.output_ways (osrm_way_id, arc_uuid, geom, tags) FROM '$$PATH$$/4316.dat';

--
-- Data for Name: output_ways_nodes; Type: TABLE DATA; Schema: public; Owner: osm
--

COPY public.output_ways_nodes (osrm_way_id, osrm_node_id, arc_uuid, "position", node) FROM stdin;
\.
COPY public.output_ways_nodes (osrm_way_id, osrm_node_id, arc_uuid, "position", node) FROM '$$PATH$$/4317.dat';

--
-- Name: topo_ways_roselend_osm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osm
--

SELECT pg_catalog.setval('public.topo_ways_roselend_osm_id_seq', 669817837, true);


--
-- Name: output_nodes osrm_nodes_roselend_pkey; Type: CONSTRAINT; Schema: public; Owner: osm
--

ALTER TABLE ONLY public.output_nodes
    ADD CONSTRAINT osrm_nodes_roselend_pkey PRIMARY KEY (osrm_node_id);


--
-- Name: output_ways_nodes osrm_ways_nodes_roselend_pkey; Type: CONSTRAINT; Schema: public; Owner: osm
--

ALTER TABLE ONLY public.output_ways_nodes
    ADD CONSTRAINT osrm_ways_nodes_roselend_pkey PRIMARY KEY (osrm_way_id, osrm_node_id, "position");


--
-- Name: output_ways osrm_ways_roselend_pkey; Type: CONSTRAINT; Schema: public; Owner: osm
--

ALTER TABLE ONLY public.output_ways
    ADD CONSTRAINT osrm_ways_roselend_pkey PRIMARY KEY (osrm_way_id);


--
-- Name: osrm_nodes_roselend_node_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_nodes_roselend_node_idx ON public.output_nodes USING gist (node);


--
-- Name: osrm_nodes_roselend_osrm_node_id_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_nodes_roselend_osrm_node_id_idx ON public.output_nodes USING btree (osrm_node_id);


--
-- Name: osrm_ways_nodes_roselend_osrm_node_id_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_nodes_roselend_osrm_node_id_idx ON public.output_ways_nodes USING btree (osrm_node_id);


--
-- Name: osrm_ways_nodes_roselend_osrm_way_id_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_nodes_roselend_osrm_way_id_idx ON public.output_ways_nodes USING btree (osrm_way_id);


--
-- Name: osrm_ways_nodes_roselend_position_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_nodes_roselend_position_idx ON public.output_ways_nodes USING btree ("position");


--
-- Name: osrm_ways_roselend_arc_uuid_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_roselend_arc_uuid_idx ON public.output_ways USING btree (arc_uuid);


--
-- Name: osrm_ways_roselend_osrm_way_id_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_roselend_osrm_way_id_idx ON public.output_ways USING btree (osrm_way_id);


--
-- Name: osrm_ways_roselend_tags_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX osrm_ways_roselend_tags_idx ON public.output_ways USING btree (tags);


--
-- Name: topo_ways_roselend_geom_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX topo_ways_roselend_geom_idx ON public.input_ways USING gist (geom);


--
-- Name: topo_ways_roselend_tags_idx; Type: INDEX; Schema: public; Owner: osm
--

CREATE INDEX topo_ways_roselend_tags_idx ON public.input_ways USING btree (tags);


--
-- PostgreSQL database dump complete
--

